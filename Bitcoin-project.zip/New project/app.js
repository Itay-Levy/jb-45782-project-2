let allCoins = [];
let selectedCoins = [];

async function loadTemplate(templateFile) {
    try {
        const html = await $.ajax({
            url: templateFile,
            method: 'GET',
            dataType: 'html'
        });
        $('#main-content').html(html);
        
        if (templateFile === 'coins.html') {
            setupSearch();
        }
        
    } catch (error) {
        $('#main-content').html('<p>Error loading content</p>');
    }
}

function setupSearch() {
    fetchCryptoData();
    
    $('#search-btn').click(function() {
        const searchTerm = $('#search-input').val().toUpperCase();
        filterCoins(searchTerm);
    });
    
    $('#search-input').keypress(function(e) {
        if (e.which == 13) {
            const searchTerm = $(this).val().toUpperCase();
            filterCoins(searchTerm);
        }
    });
}

async function fetchCryptoData() {
    try {
        $('#loading-indicator').show();
        
        const data = await $.ajax({
            url: 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1',
            method: 'GET',
            dataType: 'json'
        });
        
        allCoins = data;
        displayCoins(allCoins);
        $('#loading-indicator').hide();
        
    } catch (error) {
        $('#loading-indicator').hide();
        $('#coins-container').html('<p>Error loading data. Try again later.</p>');
    }
}

function displayCoins(coins) {
    const container = $('#coins-container');
    container.empty();
    
    coins.forEach(coin => {
        const isSelected = selectedCoins.includes(coin.id);
        const toggleText = isSelected ? 'ON' : 'OFF';
        
        const coinCard = `
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${coin.name} (${coin.symbol.toUpperCase()})</h5>
                        <p class="card-text">Price: $${coin.current_price}</p>
                        
                        <div id="info-${coin.id}" style="display: none;">
                            <p>More info will load here...</p>
                        </div>
                        
                        <button class="btn btn-info btn-sm" onclick="toggleMoreInfo('${coin.id}')">More Info</button>
                        <button class="btn btn-success btn-sm" onclick="toggleCoinSelection('${coin.id}')">Toggle ${toggleText}</button>
                    </div>
                </div>
            </div>
        `;
        container.append(coinCard);
    });
    
    updateCounter();
}

function filterCoins(searchTerm) {
    if (searchTerm === '') {
        displayCoins(allCoins);
    } else {
        const filtered = allCoins.filter(coin => 
            coin.symbol.toUpperCase().includes(searchTerm) || 
            coin.name.toUpperCase().includes(searchTerm)
        );
        displayCoins(filtered);
    }
}

// Show/hide more info with real API data
async function toggleMoreInfo(coinId) {
    const infoDiv = $('#info-' + coinId);
    
    if (infoDiv.is(':visible')) {
        infoDiv.slideUp();
        return;
    }
    
    // Show loading
    infoDiv.html('<p>Loading...</p>').slideDown();
    
    try {
        // Get detailed coin data from API
        const coinData = await $.ajax({
            url: `https://api.coingecko.com/api/v3/coins/${coinId}`,
            method: 'GET',
            dataType: 'json'
        });
        
        // Build the detailed info HTML
        const detailsHtml = `
            <div class="mt-3 p-3">
                <div class="row">
                    <div class="col-md-3">
                        <img src="${coinData.image.small}" alt="${coinData.name}" style="width: 50px;">
                    </div>
                    <div class="col-md-9">
                        <h6><strong>${coinData.name} (${coinData.symbol.toUpperCase()})</h6>
                        <p>Current Prices:</strong></p>
                        <ul>
                            <li>USD: $${coinData.market_data.current_price.usd}</li>
                            <li>EUR: €${coinData.market_data.current_price.eur}</li>
                            <li>ILS: ₪${coinData.market_data.current_price.ils}</li>
                        </ul>
                    </div>
                </div>
            </div>
        `;
        
        // Show the real data
        infoDiv.html(detailsHtml);
        
    } catch (error) {
        console.error('Error getting coin details:', error);
        infoDiv.html('<p>Error loading coin details. Try again.</p>');
    }
}

function toggleCoinSelection(coinId) {
    if (selectedCoins.includes(coinId)) {
        selectedCoins = selectedCoins.filter(id => id !== coinId);
    } else {
        if (selectedCoins.length >= 5) {
            alert('You can only select 5 coins maximum!');
            return;
        }
        selectedCoins.push(coinId);
    }
    
    if ($('#search-input').val()) {
        filterCoins($('#search-input').val().toUpperCase());
    } else {
        displayCoins(allCoins);
    }
}

function updateCounter() {
    $('#show-selected-btn').text(`Selected: ${selectedCoins.length}/5`);
}

function showSelectedCoins() {
    if (selectedCoins.length === 0) {
        alert('No coins selected!');
        return;
    }
    
    const selectedCoinsData = allCoins.filter(coin => selectedCoins.includes(coin.id));
    displayCoins(selectedCoinsData);
    $('#search-input').val('');
}