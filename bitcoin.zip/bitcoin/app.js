$(function () {
  const appDiv = $("#app");
  let allCoins = [];

  
  loadCoins();

  
  $("a[data-view]").on("click", function (e) {
    e.preventDefault();
    const view = $(this).data("view");

    if (view === "coins") {
      showCoins(allCoins);
    } else if (view === "reports") {
      appDiv.html("<h2>Reports</h2><p>No reports.</p>");
    } else if (view === "about") {
      appDiv.html(`
        <div>
          <h2>About</h2>
          <p>This project shows coins from the CoinGecko API.</p>
        </div>
      `);
    }
  });

 
  $("#searchForm").on("submit", function (e) {
    e.preventDefault();
    const text = $("#searchInput").val().toLowerCase();
    const found = allCoins.filter(c => 
      c.symbol.toLowerCase().includes(text) || 
      c.name.toLowerCase().includes(text)
    );
    showCoins(found);
  });

  
  $("#clearBtn").on("click", function () {
    $("#searchInput").val("");
    showCoins(allCoins);
  });

  function loadCoins() {
    $.ajax({
      url: "https://api.coingecko.com/api/v3/coins/list",
      method: "GET",
      success: function (data) {
        allCoins = data.slice(0, 100);
        showCoins(allCoins);
      },
      error: function () {
        appDiv.html("<p>Could not load coins. Please try again later.</p>");
      }
    });
  }

  function showCoins(coins) {
    let html = '<div class="row">';
    coins.forEach(function (c) {
      html += `
        <div class="col-sm-6 col-md-4 mb-3">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">${c.symbol.toUpperCase()}</h5>
              <p class="card-text">${c.name}</p>
              <small>ID: ${c.id}</small>
            </div>
          </div>
        </div>
      `;
    });
    html += "</div>";
    appDiv.html(html);
  }
});
